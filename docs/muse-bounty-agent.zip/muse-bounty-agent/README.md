# MUSE BOUNTY AGENT — Isolated Workspace

Workspace independen untuk mengerjakan **coding bounties di make.fun** dengan Muse. Ini **bukan** paket skill bug-bounty pentesting; security testing hanya boleh dilakukan pada target yang jelas diizinkan.

## Status paket

- **Sudah tersedia:** 7 skill buatan workspace + 1 skill asli dari GitHub (`web-design-guidelines`) dengan atribusi, kebijakan agent, skrip pengelola workspace, katalog sumber GitHub yang sudah ditentukan, dan test lokal.
- **Belum dilakukan:** memasang di Muse milik Anda, mengunduh repo GitHub lain, menghubungkan akun, mengerjakan bounty, merekam sesi, atau melakukan submission.
- Skill GitHub tambahan harus dipilih & ditinjau; **jangan install semua secara otomatis**.

## Struktur

```text
muse-bounty-agent/
├── AGENTS.md                  # Kebijakan agent utama
├── MUSE_START_PROMPT.md       # Prompt siap tempel ke Muse
├── MUSE_APP_SETUP_PROMPT.md   # Jika menjalankan Muse App cloud
├── .agents/skills/            # Skill project-scoped untuk Muse Code
├── config/skills-sources.json # Daftar sumber GitHub yang boleh diperiksa
├── scripts/workspace.py       # Manager source/skill/bounty dan doctor
├── docs/WORKFLOW.md           # Alur bounty yang dapat diaudit
├── docs/SECURITY.md           # Kebijakan supply-chain dan privasi
├── bounties/                  # Satu direktori per bounty
└── third_party/               # Staging GitHub; diabaikan Git
```

## Pilihan A — Muse Code di Windows (fitur project skills resmi)

1. Ekstrak ZIP ini, misalnya ke `D:\Project\muse-bounty-agent`.
2. Buka PowerShell di folder tersebut, jalankan `python scripts/workspace.py doctor`.
3. Jalankan `muse` **di dalam folder tersebut**. Pada awal pemakaian, periksa dan trust hanya isi workspace yang Anda pahami.
4. Tempel isi `MUSE_START_PROMPT.md` ke Muse.
5. Pastikan `muse skills list` memperlihatkan skill lokal. Muse Code memindai `.agents/skills/` pada trusted project.

Muse Code berbeda dari Muse App di browser. Perintah CLI di atas hanya berlaku bila biner `muse` tersedia.

## Pilihan B — Muse App / cloud Hatch

Unggah ZIP ini ke Muse (jika aplikasi mendukung unggahan file), lalu tempel isi `MUSE_APP_SETUP_PROMPT.md`. Minta Muse mengekstrak file ke direktori proyek terpisah, memeriksa skill dan menggunakan instruksi secara eksplisit. **Jangan mengasumsikan Muse App memuat otomatis `.agents/skills/`**. Jika akses file atau shell tidak tersedia, minta Muse melaporkan keterbatasannya, bukan mengaku sudah memasang.

## Perintah manajemen lokal

```bash
python scripts/workspace.py doctor
python scripts/workspace.py sources
python scripts/workspace.py new --slug nama-bounty
python scripts/workspace.py fetch --source vercel-agent-skills
python scripts/workspace.py catalog --source vercel-agent-skills
python scripts/workspace.py review --source vercel-agent-skills --skill react-best-practices
# Jalankan install HANYA setelah membaca isi skill dan menyetujui pemasangan
python scripts/workspace.py install --source vercel-agent-skills --skill react-best-practices --reviewed
```

`fetch` mengunduh repo GitHub ke `third_party/` tanpa menjalankan installer. `install` menyalin folder skill ke `.agents/skills/`, bukan mengaktifkan eksekusi otomatis. Skill asli/skrip pihak ketiga masih harus diaudit; ada risiko prompt injection. Tidak ada sinkronisasi otomatis.

## Sumber otoritatif

- [make.fun agent instructions](https://make.fun/skill.md): baca ulang untuk setiap bounty.
- [make.fun requirements API](https://make.fun/api/competitions): periksa rules dan prerequisites per slug.
- [Muse Code skills](https://dev.meta.ai/docs/muse-code/extending): `.agents/skills` project-scoped.
- [Agent Skills specification](https://agentskills.io/).

## Pengingat penting

make.fun dapat meminta rekaman resmi sejak awal sesi kerja, run record, artefak kode, dan seluruh transcript terkait. Periksa dulu persyaratan bounty; jangan menganggap proyek lama valid hanya karena dipindahkan ke workspace baru. Dilarang membuat rekaman, bukti, skor, atau provenance palsu. Kirim submission hanya dengan persetujuan eksplisit manusia.
