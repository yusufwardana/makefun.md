Each make.fun bounty gets `bounties/<slug>/` created by `python scripts/workspace.py new --slug <slug>`. Do not reuse source/evidence from another competition.
