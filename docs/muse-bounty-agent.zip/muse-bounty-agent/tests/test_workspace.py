"""Offline package validations; no network or third-party code execution."""
from pathlib import Path
import json
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]

class WorkspaceTests(unittest.TestCase):
    def test_core_files_exist(self):
        for name in ['README.md','AGENTS.md','MUSE_START_PROMPT.md','MUSE_APP_SETUP_PROMPT.md',
                     'scripts/workspace.py','docs/SECURITY.md','docs/WORKFLOW.md']:
            self.assertTrue((ROOT/name).is_file(), name)

    def test_skills_have_headers(self):
        skills=list((ROOT/'.agents/skills').glob('*/SKILL.md'))
        self.assertEqual(len(skills),8)
        for p in skills:
            src=p.read_text(encoding='utf8')
            self.assertTrue(src.startswith('---\n'),p)
            self.assertIn('name: '+p.parent.name,src)
            self.assertRegex(src,r'(?m)^description: .+')

    def test_all_sources_allowlisted_and_not_autoinstall(self):
        sources=json.loads((ROOT/'config/skills-sources.json').read_text())['sources']
        self.assertTrue(sources)
        for s in sources:
            self.assertTrue(s['repo'].startswith('https://github.com/'))
            self.assertFalse(s['default_install'])
            self.assertRegex(s['id'],r'^[a-z0-9-]+$')

    def test_policy_restricts_submission_and_paths(self):
        ag=(ROOT/'AGENTS.md').read_text()
        self.assertIn('explicit',ag)
        self.assertIn('bounties/<slug>/',ag)
        self.assertIn('GitHub',ag)

if __name__=='__main__':
    unittest.main()
