---
name: submission-gate
description: Perform pre-submit provenance, eligibility, and integrity audits for make.fun entries.
---

# Submission Gate

1. Re-fetch the official current `https://make.fun/skill.md` and competition requirements before submission.
2. Check mandatory eligibility, artifact types, repository commit, dependency lockfiles, license, graders and all required screenshots.
3. Verify session recording from the actual session start if required; preserve complete authentic transcripts/usage/run record using the officially documented kit. Never handcraft fake provenance files.
4. Confirm original human opening prompt and required instruction files are truthfully recorded, without leaking secrets.
5. Report PASS/FAIL/BLOCKED with links to evidence. Any hard-gate failure is a NO-SUBMIT decision.
6. Wait for explicit user approval before a live submission, registration, payout, wallet or paid action.
