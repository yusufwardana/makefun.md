---
name: qa-evidence
description: Verify functionality through actual runnable tests and preserve faithful evidence.
---

# QA & Evidence

1. Run lint/typecheck/build/unit/integration/E2E where relevant. Capture exact commands, exit codes and dated logs.
2. Test actual rendered UI or game mechanics, not just compilation. Capture genuine screenshots when the task requires them.
3. Compare observed behavior with `quality-matrix.md`; highlight missing coverage and blockers.
4. Fix the highest-value real failure, rerun tests, and record regression results.
5. Never fabricate evidence, edit a transcript to hide substantive changes, or claim unrun tests passed.
