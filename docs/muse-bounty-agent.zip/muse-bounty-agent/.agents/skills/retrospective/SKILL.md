---
name: retrospective
description: Improve repeated bounty work through verified lessons rather than uncontrolled prompt changes.
---

# Bounty Retrospective

1. After each completed session, compare actual objective outcomes to the initial rubric and evidence.
2. Record reproducible defects, the corrective change, validated improvement and reusable test cases.
3. Update local playbooks only when learning is broadly applicable and does not conflict with upstream requirements.
4. Avoid unbounded autonomous self-editing or background monitoring without permission.
