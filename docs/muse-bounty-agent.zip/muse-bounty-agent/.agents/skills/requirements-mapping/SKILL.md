---
name: requirements-mapping
description: Convert official bounty requirements into testable implementation and grading criteria.
---

# Requirements Mapping

1. Copy or link the current authoritative bounty requirements into notes with source URL and retrieval date.
2. Separate must-pass eligibility, required features, performance metric, visual polish, optional bonuses and submission/provenance rules.
3. Make a matrix: requirement, exact test, existing evidence, status (`NOT_STARTED`, `PARTIAL`, `PASS`, `FAIL`, `BLOCKED`). Do not mark PASS without execution.
4. Prioritize hard gates and official metric first. Record assumptions and unresolved conditions honestly.
5. Keep the matrix synchronized after every verified change.
