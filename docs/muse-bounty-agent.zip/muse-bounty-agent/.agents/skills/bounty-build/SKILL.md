---
name: bounty-build
description: Build one complete runnable coding bounty entry in its isolated folder.
---

# Bounty Build

1. Work only in `bounties/<slug>/solution/`, with a separate Git repository as demanded by that bounty.
2. Verify the official recording session/provenance prerequisites **before** starting a new build when mandated by make.fun.
3. Implement real functionality, not fake screenshots or static mockups. Prefer simple complete architecture, original or licensed assets, and small measurable increments.
4. Record commands and version facts only from actual tooling; use project-specific QA and performance skills as needed.
5. Do not publish, push to external repositories, or submit without the user's explicit authorization.
