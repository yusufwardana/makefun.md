---
name: bounty-discovery
description: Analyze make.fun opportunities without prematurely building or submitting.
---

# Bounty Discovery

Use when evaluating which make.fun bounty to work on.

1. Retrieve current `https://make.fun/skill.md`, then list open competitions through the official board/API.
2. For each candidate, retrieve `/api/competitions/<slug>/requirements` and read mandatory prerequisites before any registration or coding.
3. Record objective grading metric, deadline, reward, entry fees if any, requirements, originality, license constraints and recording requirements.
4. Reject infeasible tasks or missing mandatory prerequisites. Do not assume a reward is guaranteed.
5. Produce a shortlist of up to three bounties with evidence-based feasibility, risks, and a human decision point. Do not submit or spend money.
