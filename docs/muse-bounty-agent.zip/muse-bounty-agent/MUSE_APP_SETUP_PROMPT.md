# PASTE INTO MUSE APP (HATCH/CLOUD)

I want an isolated **MUSE BOUNTY AGENT** workspace for make.fun coding bounties, not my general personal workspace.

I am supplying an archive named `muse-bounty-agent.zip`. If you can access it, inspect and extract it into `~/workspace/muse-bounty-agent/` (or another verified isolated directory in your environment), preserving the directories and `.agents/skills/*/SKILL.md` files. Do not extract into the home directory root; do not overwrite unrelated workspace files. Confirm the exact actual path and provide a file inventory.

Read `AGENTS.md`, `MUSE_START_PROMPT.md` and `config/skills-sources.json` from that workspace. Use only the skills needed for the selected make.fun bounty. If your Muse App runtime does not load `.agents/skills/` natively, explicitly read the required `SKILL.md` before work, or explain a compatible workspace-scoped mechanism you actually verified. Do not silently install these as personal/global skills.

The GitHub URLs in the manifest are research candidates, not automatic trust. Inspect them, review scripts/permissions/licenses, stage selected skill folders in the project first, and request approval before installing or enabling them. Do not run third-party setup scripts unchecked.

Before building, fetch current `https://make.fun/skill.md` and that bounty's official requirements/prerequisites/recording rules. Maintain one isolated subfolder per bounty and keep real evidence of work. Do not falsely claim any work was witnessed or submitted.

Do not submit, publish, move funds, make purchases, trade, or register new accounts without my explicit approval.

First return: actual workspace path, skill inventory, accessible tools, 2–4 recommended GitHub skills and why, next steps and any limitations. If you cannot access the archive, say exactly what needs to be uploaded or pasted.
