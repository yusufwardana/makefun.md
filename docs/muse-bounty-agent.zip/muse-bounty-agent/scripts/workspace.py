#!/usr/bin/env python3
"""Safe, project-scoped Muse bounty workspace management. Python stdlib only."""
import argparse
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SKILLS = ROOT / '.agents' / 'skills'
SOURCES = ROOT / 'config' / 'skills-sources.json'
STAGE = ROOT / 'third_party'
BOUNTIES = ROOT / 'bounties'
LOCK = ROOT / 'skills.lock.json'
VALID_ID = re.compile(r'^[a-z0-9]+(?:-[a-z0-9]+)*$')


def fail(msg):
    raise RuntimeError(msg)


def manifest():
    data = json.loads(SOURCES.read_text(encoding='utf-8'))
    assert data['schema_version'] == 1
    return {s['id']: s for s in data['sources']}


def source(name):
    sources = manifest()
    if name not in sources:
        fail('Unknown source id; use `sources` to list allowed sources')
    return sources[name]


def stage_for(name):
    return STAGE / name


def git(*args, cwd=None):
    result = subprocess.run(['git', *args], cwd=cwd, capture_output=True, text=True, check=True)
    return result.stdout.strip()


def skill_header(path):
    data = path.read_text(encoding='utf-8')
    match = re.match(r'^---\s*\n(.*?)\n---\s*\n', data, re.S)
    if not match:
        fail(f'Invalid SKILL.md frontmatter: {path}')
    fields = {}
    for line in match.group(1).splitlines():
        m = re.match(r'^([\w-]+):\s*(.+?)\s*$', line)
        if m:
            fields[m.group(1)] = m.group(2).strip('"\'')
    if not fields.get('name') or not fields.get('description'):
        fail(f'SKILL.md must define name and description: {path}')
    return fields


def catalogue(name):
    base = stage_for(name)
    if not (base / '.git').exists():
        fail(f'Source {name} not fetched. Run fetch --source {name} first.')
    result = {}
    for file in base.rglob('SKILL.md'):
        if '.git' in file.parts or file.is_symlink():
            continue
        rel = file.relative_to(base)
        if len(rel.parts) > 6:
            continue
        try:
            fields = skill_header(file)
            sid = fields['name']
            if VALID_ID.fullmatch(sid):
                result.setdefault(sid, []).append(file)
        except (RuntimeError, UnicodeDecodeError):
            continue
    return result


def choose(name, skill):
    found = catalogue(name).get(skill, [])
    if not found:
        fail(f'Skill {skill!r} not found in {name}')
    if len(found) != 1:
        fail(f'Ambiguous skill {skill!r}; inspect manually: {found}')
    candidate = found[0]
    if candidate.parent.is_symlink() or not candidate.resolve().is_relative_to(stage_for(name).resolve()):
        fail('Source skill path escapes staging directory')
    return candidate


def validate_directory(folder):
    if not folder.is_dir():
        fail(f'Not a skill directory: {folder}')
    fields = skill_header(folder / 'SKILL.md')
    if fields['name'] != folder.name:
        fail(f'Skill directory {folder.name} does not match frontmatter name {fields["name"]}')
    for entry in folder.rglob('*'):
        if entry.is_symlink():
            fail(f'Symlinks prohibited in installed skill: {entry}')
        if not entry.resolve().is_relative_to(folder.resolve()):
            fail(f'Path traversal in skill: {entry}')
    return fields


def do_doctor(_):
    errors = []
    for required in ['AGENTS.md', 'README.md', 'MUSE_START_PROMPT.md', 'config/skills-sources.json']:
        if not (ROOT / required).is_file():
            errors.append(f'Missing: {required}')
    try:
        sources = manifest()
        for sid, info in sources.items():
            if not VALID_ID.fullmatch(sid) or not info['repo'].startswith('https://github.com/'):
                errors.append(f'Malformed source: {sid}')
    except Exception as e:
        errors.append(f'Bad manifest: {e}')
    for d in sorted(SKILLS.iterdir()):
        if d.is_dir():
            try:
                validate_directory(d)
            except Exception as e:
                errors.append(str(e))
    print(f'WORKSPACE {ROOT}')
    print(f'LOCAL SKILLS ({len([d for d in SKILLS.iterdir() if d.is_dir()])}):')
    for d in sorted(SKILLS.iterdir()):
        if d.is_dir():
            print(f'  - {d.name}')
    print('STATUS:', 'PASS' if not errors else 'FAIL')
    for e in errors:
        print('ERROR:', e)
    return 0 if not errors else 1


def do_sources(_):
    for sid, info in manifest().items():
        flag = ' [SECURITY-RESTRICTED]' if info.get('restricted') else ''
        print(f'{sid}{flag}\n  {info["repo"]}\n  {info["purpose"]}')


def do_fetch(args):
    info = source(args.source)
    dest = stage_for(args.source)
    if dest.exists():
        fail(f'Already staged: {dest}. Review manually before updating; no automatic overwrites.')
    git('clone', '--depth', '1', '--', info['repo'], str(dest))
    print('FETCHED', info['repo'], 'COMMIT', git('rev-parse', 'HEAD', cwd=dest))
    print('No installer or executable from GitHub was run.')


def do_catalog(args):
    items = catalogue(args.source)
    for sid, files in sorted(items.items()):
        print(f'{sid}: {", ".join(str(p.relative_to(stage_for(args.source))) for p in files)}')
    print(f'FOUND {len(items)} unique names; no code executed.')


def do_review(args):
    info = source(args.source)
    path = choose(args.source, args.skill)
    print('SOURCE', info['repo'])
    print('COMMIT', git('rev-parse', 'HEAD', cwd=stage_for(args.source)))
    print('SKILL', path.relative_to(stage_for(args.source)))
    print('\n=== SKILL.md ===\n')
    print(path.read_text(encoding='utf-8'))
    print('\n=== FILE INVENTORY (must inspect every applicable script/dependency) ===')
    for file in sorted(path.parent.rglob('*')):
        if file.is_file():
            print(' ', file.relative_to(path.parent), f'{file.stat().st_size} bytes', '(SYMLINK)' if file.is_symlink() else '')
    print('\nREVIEW REQUIRED: scripts, dependencies, permissions, license, secrets, paths, downstream sources.')


def do_install(args):
    if not args.reviewed:
        fail('Install blocked: --reviewed required after reading SKILL.md and all associated files.')
    info = source(args.source)
    if info.get('restricted'):
        fail('This source is restricted: security tooling requires a separate authorized scope review.')
    if not VALID_ID.fullmatch(args.skill):
        fail('Unsafe skill name')
    skillfile = choose(args.source, args.skill)
    incoming = skillfile.parent
    validate_directory(incoming)
    dest = SKILLS / args.skill
    if dest.exists():
        fail(f'Destination exists (no overwrites): {dest}')
    shutil.copytree(incoming, dest, symlinks=False)
    try:
        validate_directory(dest)
    except BaseException:
        shutil.rmtree(dest)
        raise
    sha = git('rev-parse', 'HEAD', cwd=stage_for(args.source))
    lock = json.loads(LOCK.read_text(encoding='utf-8')) if LOCK.exists() else {'schema_version': 1, 'skills': {}}
    lock['skills'][args.skill] = {'source': args.source, 'repo': info['repo'], 'commit': sha,
                                   'path': str(skillfile.relative_to(stage_for(args.source))), 'reviewed': True}
    LOCK.write_text(json.dumps(lock, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print('INSTALLED', args.skill, 'to', dest, 'from commit', sha)
    print('NOTE: Imported skill instructions/scripts are not independently proven safe by this tool.')


def do_new(args):
    slug = args.slug
    if not VALID_ID.fullmatch(slug):
        fail('Bounty slug must be lowercase letters/digits/hyphens')
    dest = BOUNTIES / slug
    if dest.exists():
        fail('Bounty directory already exists; refusing overwrite')
    dest.mkdir(parents=True)
    (dest / 'solution').mkdir()
    (dest / 'evidence').mkdir()
    (dest / 'requirements.md').write_text('# Official requirements\n\nStatus: NOT_VERIFIED\nURL: \nChecked at: \nPrerequisites: \nRecording requirements: \n', encoding='utf-8')
    (dest / 'quality-matrix.md').write_text('# Quality matrix\n\n| Criterion | Test | Evidence | Status |\n|---|---|---|---|\n| To be read from official rules | | | NOT_STARTED |\n', encoding='utf-8')
    (dest / 'skills-reviewed.md').write_text('# GitHub skill review\n\nNothing reviewed yet.\n', encoding='utf-8')
    (dest / 'submission-checklist.md').write_text('# Submission readiness\n\nStatus: NO_SUBMIT / NOT_VERIFIED\n- [ ] Official latest requirements checked\n- [ ] Prerequisites met\n- [ ] Runnable solution tested\n- [ ] All required authentic recordings/transcripts/run records checked\n- [ ] User explicitly approved submission\n', encoding='utf-8')
    print('CREATED isolated bounty folder:', dest)
    print('No recording, source implementation or submission has occurred.')


def cli(argv=None):
    p = argparse.ArgumentParser(description='Manage isolated Muse Bounty Agent workspace and reviewed GitHub skills')
    sp = p.add_subparsers(dest='action', required=True)
    sp.add_parser('doctor')
    sp.add_parser('sources')
    for cmd in ['fetch','catalog','review','install']:
        sub = sp.add_parser(cmd)
        sub.add_argument('--source', required=True)
        if cmd in {'review','install'}:
            sub.add_argument('--skill', required=True)
        if cmd == 'install':
            sub.add_argument('--reviewed', action='store_true', help='Confirm all contents reviewed before copying')
    sub = sp.add_parser('new');sub.add_argument('--slug',required=True)
    args=p.parse_args(argv)
    try:
        return {'doctor':do_doctor,'sources':do_sources,'fetch':do_fetch,'catalog':do_catalog,
                'review':do_review,'install':do_install,'new':do_new}[args.action](args) or 0
    except (RuntimeError, FileNotFoundError, OSError, subprocess.CalledProcessError, ValueError) as e:
        print('ERROR:',e,file=sys.stderr);return 2

if __name__=='__main__':
    sys.exit(cli())
