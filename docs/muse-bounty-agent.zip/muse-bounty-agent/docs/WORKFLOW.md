# Evidence-first execution workflow

| Stage | Purpose | Output | Gate |
|---|---|---|---|
| Intake | Read current make.fun `skill.md` and selected bounty requirements | `requirements.md` and prerequisites list | Mandatory prerequisites verified |
| Source review | Find relevant skills via allowlisted GitHub repos | `skills-reviewed.md` with source commit/risks | Review before installation |
| Plan | Map rubric to implementation and tests | `quality-matrix.md` | Only measurable work selected |
| Build | Produce runnable original code | `solution/` repo | New session recording if required |
| Verify | Run real tests, compare against rubric | `evidence/` logs, screenshots, results | PASS means executed |
| Submit gate | Inspect run record, complete transcripts, repository, hashes, API checks | `submission-checklist.md` | Human approval required |

For every run, log what was observed, with timestamps and commands. Do not manufacture data. Refresh the upstream rules at the start of each bounty and before final submission. The official kit/CLI determines acceptable provenance formats; never handcraft fake run records.

## Score optimization

Prioritize (1) eligibility and submission requirements, (2) complete core functionality, (3) deterministic tests and grader compatibility, (4) high-impact usability/performance, and finally (5) polish. Rerun targeted tests after each fix. Stop when improvements are speculative or deadlines prevent proper verification.
