# GitHub skill review and environment boundaries

## Why this matters
A skill can contain instructions that redirect an agent, source files that run commands, or dependencies with full machine privileges. GitHub links are NOT proof of trust.

## Before installation
- Verify upstream URL and git commit; read full `SKILL.md` and every script referenced, plus license and dependency files.
- Reject secret-exfiltration, wallet manipulation, persistence, unsolicited telemetry, external publishing, unrestricted shell execution and privilege escalation.
- Only copy the selected skill folder after review; avoid `curl | sh`, `npm install` lifecycle scripts, and running `install.sh` without inspection.
- The source manifest does not grant permission to install or execute anything.
- Keep credentials out of `.env` committed files, transcripts and evidence. Prefer approved credential interfaces.
- Updates require fresh review; no automatic updating after pinning a commit.

## Repo separation
Third-party repos stage in `third_party/` (not committed). Only explicitly selected skill folders are copied to `.agents/skills/`. One bounty's solution goes to its own folder. The script rejects symlinks and path traversal in copied skill folders.

## Distinguish bounty classes
`make.fun` coding bounties involve building and grading software. Security bug-bounty programs involve testing systems; do not perform active scanning unless there is explicit scope and authorization.
