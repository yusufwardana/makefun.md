GitHub sources are staged here only after a deliberate `fetch`. Source checkouts are not trusted and are gitignored. Their scripts must never be executed automatically.
